import type { Config } from "tailwindcss";
const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        heat: {
          50: "#FFF6EE",
          100: "#FFE8D3",
          200: "#FFD0A6",
          300: "#FFB36E",
          400: "#FF9141",
          500: "#FF6F14",
          600: "#E65E0F",
          700: "#BF4A0C",
          800: "#9A3B0A",
          900: "#7D3008"
        }
      }
    },
  },
  plugins: [],
};
export default config;
