"use client";
import Button from "@/components/ui/Button";

export default function SettingsPage(){
  return (
    <div className="container-7xl py-10">
      <h1 className="text-2xl font-bold">Einstellungen</h1>
      <div className="mt-6 rounded-2xl border bg-white p-6 max-w-xl">
        <label className="block text-sm text-slate-600">Standort</label>
        <input className="mt-1 w-full h-11 px-3 rounded-xl border" placeholder="z. B. Stuttgart" />
        <label className="block text-sm text-slate-600 mt-4">API-Schlüssel (Wetter)</label>
        <input className="mt-1 w-full h-11 px-3 rounded-xl border" placeholder="OpenWeather / DWD" />
        <div className="mt-6 flex gap-3">
          <Button>Speichern</Button>
          <Button variant="outline">Abbrechen</Button>
        </div>
      </div>
    </div>
  )
}
