export default function AnalysisPage(){
  return (
    <div className="container-7xl py-10">
      <h1 className="text-2xl font-bold">Analyse & Dokumentation</h1>
      <div className="mt-6 space-y-4 text-slate-700">
        <p>Die Abweichungsanalyse vergleicht den gemessenen Heizenergieverbrauch mit dem berechneten Bedarf. Bei Abweichungen &gt; 15% wird ein Warnhinweis generiert und im Abweichungsbericht gemäß § 6 HKVO dokumentiert.</p>
        <p>Wetterabgleich: Median der Differenz (Temperatur, hPa) zwischen lokaler Messung und API-Quelle (DWD/OpenWeather) wird kontinuierlich gespeichert.</p>
        <p>Export: Der PDF-Export bündelt Wetterdaten, Verbrauch, Begründungstexte und Hinweise rechtssicher.</p>
      </div>
    </div>
  )
}
