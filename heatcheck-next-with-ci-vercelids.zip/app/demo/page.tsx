"use client";
import Link from "next/link";
import Button from "@/components/ui/Button";

export default function DemoPage(){
  return (
    <div className="container-7xl py-10">
      <h1 className="text-2xl font-bold">Live-Demo (Simulation)</h1>
      <p className="mt-2 text-slate-600">Verbinde einen simulierten Sensor oder starte mit Demo-Daten.</p>
      <div className="mt-6 flex gap-3">
        <Button>Sensor verbinden</Button>
        <Link href="/dashboard"><Button variant="outline">Zur Auswertung</Button></Link>
      </div>
      <div className="mt-10 rounded-2xl border bg-white p-6">
        <h2 className="font-semibold">Demo-Status</h2>
        <ul className="mt-3 list-disc pl-5 text-sm text-slate-700">
          <li>2 virtuelle Räume aktiv</li>
          <li>Wetterabgleich: Quelle DWD, Median Δ 0.6°C</li>
          <li>PDF-Export via Druckdialog (Button)</li>
        </ul>
      </div>
    </div>
  )
}
