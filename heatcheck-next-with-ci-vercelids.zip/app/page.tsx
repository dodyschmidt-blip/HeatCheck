"use client";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import Button from "@/components/ui/Button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Thermometer, Droplets, Wind, ShieldCheck, BarChart3, PlugZap, Sparkles, Check } from "lucide-react";

const features = [
  { icon: Thermometer, title: "Echtzeit-Heizbedarf", desc: "Minütliche Berechnung auf Raumebene – mit Dämmung, Volumen, Möblierung und Lüftungsprofil." },
  { icon: Droplets, title: "Feuchte & Druck", desc: "Automatische Korrektur nach Luftfeuchte und lokalem Luftdruck (Balkon-Barometer)." },
  { icon: Wind, title: "Wetter-API-Abgleich", desc: "Vergleich lokaler Messung mit DWD/OpenWeather inkl. Median-Differenzspeicher." },
  { icon: ShieldCheck, title: "Abweichungsbericht", desc: ">15% Warnlogik mit §6 HKVO-Hinweis, PDF-Export in einem Klick." },
  { icon: BarChart3, title: "Transparente Auswertung", desc: "Tages-, Monats- und Jahresansicht mit Forecast und Abweichungsanalyse." },
  { icon: PlugZap, title: "Sensor-Ready", desc: "BLE/WiFi-Sensorik, Demo-Simulator, spätere Bosch-Integration vorgesehen." },
];

const checklist = [
  "Privat kostenlos, gewerblich lizenziert",
  "Registrierung & Lizenzprüfung integriert",
  "PDF-Exports für Behörden & Investoren",
  "Mehrsprachig (DE/EN/HU)",
];

export default function Page(){
  return (
    <div>
      {/* Hero */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <Image src="/hero-bg.jpg" alt="" fill className="object-cover opacity-80" priority />
          <div className="absolute inset-0 bg-gradient-to-b from-white/60 to-white" />
        </div>
        <div className="container-7xl py-20 md:py-28">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <motion.h1 initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} transition={{duration:0.5}}
                className="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900">
                Heizverbrauch in Echtzeit. <span className="text-heat-600">Transparent. Smart. Rechtssicher.</span>
              </motion.h1>
              <p className="mt-5 text-lg text-slate-600">
                HeatCheck ermittelt deinen tatsächlichen Heizenergiebedarf auf Raumebene – unter Berücksichtigung von
                Raumgröße, Dämmung, Möblierung, Luftaustausch, Luftdruck und Feuchtigkeit. Mit KI-Empfehlungen und
                Abweichungsbericht nach §6 HKVO.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3">
                <Link href="/demo"><Button size="lg" className="bg-slate-900 hover:bg-slate-800">Kostenlos testen</Button></Link>
                <Link href="/analysis"><Button size="lg" variant="outline" className="border-heat-300">Dokumentation</Button></Link>
              </div>
              <ul className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-slate-600">
                {checklist.map((c,i)=> (
                  <li key={i} className="flex items-center gap-2"><Check className="h-4 w-4"/>{c}</li>
                ))}
              </ul>
            </div>
            {/* Mock device panel */}
            <motion.div id="demo" initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} transition={{delay:0.1, duration:0.6}}>
              <Card className="rounded-2xl shadow-xl border-heat-100">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-heat-600" /> Live-Demo (Simulation)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl border bg-white">
                      <div className="text-sm text-slate-500">Wohnzimmer</div>
                      <div className="mt-1 text-2xl font-semibold">21.3°C</div>
                      <div className="mt-1 text-slate-500">Soll: 20.5°C • Abweichung: <span className="text-emerald-600">+3%</span></div>
                    </div>
                    <div className="p-4 rounded-xl border bg-white">
                      <div className="text-sm text-slate-500">Schlafzimmer</div>
                      <div className="mt-1 text-2xl font-semibold">18.9°C</div>
                      <div className="mt-1 text-slate-500">Soll: 19.5°C • Abweichung: <span className="text-rose-600">-4%</span></div>
                    </div>
                    <div className="p-4 rounded-xl border bg-white">
                      <div className="text-sm text-slate-500">Feuchte</div>
                      <div className="mt-1 text-2xl font-semibold">47%</div>
                      <div className="mt-1 text-slate-500">Druck: 1009 hPa</div>
                    </div>
                    <div className="p-4 rounded-xl border bg-white">
                      <div className="text-sm text-slate-500">Wetterabgleich</div>
                      <div className="mt-1 text-2xl font-semibold">Median Δ: 0.6°C</div>
                      <div className="mt-1 text-slate-500">Quelle: DWD • Lokal</div>
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[Thermometer, Droplets, Wind, BarChart3].map((Icon, i) => (
                      <div key={i} className="flex items-center gap-2 rounded-xl border p-3">
                        <Icon className="h-5 w-5" />
                        <span className="text-sm">Metric {i+1}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 flex flex-wrap gap-3">
                    <Button variant="outline" onClick={()=>window.print()}>PDF Abweichungsbericht</Button>
                    <Link href="/demo"><Button>Sensor verbinden</Button></Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Feature grid */}
      <section id="features" className="container-7xl pb-14">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold">Alles, was du brauchst</h2>
          <p className="mt-2 text-slate-600">Von der Messung bis zum rechtssicheren PDF-Report – in einer App.</p>
        </div>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, idx) => (
            <div key={idx} className="h-full border-heat-100 rounded-2xl border bg-white p-6">
              <div className="flex items-center gap-3">
                <f.icon className="h-5 w-5 text-heat-600" />
                <h3 className="font-semibold">{f.title}</h3>
              </div>
              <p className="mt-3 text-sm text-slate-600">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="bg-slate-50 border-t border-heat-100/60">
        <div className="container-7xl py-16">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold">Einfache, faire Preise</h2>
            <p className="mt-2 text-slate-600">Privat kostenlos. Gewerblich mit Lizenz – transparent und skalierbar.</p>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-6">
            <div className="rounded-2xl border bg-white border-slate-200">
              <div className="p-5 border-b"><h3 className="font-semibold">Free (Privat)</h3></div>
              <div className="p-5">
                <div className="text-4xl font-extrabold">0€</div>
                <p className="mt-1 text-sm text-slate-500">für private Nutzung</p>
                <ul className="mt-4 space-y-2 text-sm text-slate-600">
                  <li className="flex gap-2">• Live-Demo & Basis-Reports</li>
                  <li className="flex gap-2">• 2 Räume / 1 Standort</li>
                  <li className="flex gap-2">• PDF-Export (Watermark)</li>
                </ul>
                <div className="mt-6"><a href="/demo"><button className="w-full h-11 px-4 rounded-2xl bg-slate-900 text-white">Loslegen</button></a></div>
              </div>
            </div>

            <div className="rounded-2xl border bg-white border-heat-200 ring-1 ring-heat-200">
              <div className="p-5 border-b"><h3 className="font-semibold">Pro (Gewerblich)</h3></div>
              <div className="p-5">
                <div className="text-4xl font-extrabold">29€</div>
                <p className="mt-1 text-sm text-slate-500">pro Monat / Standort</p>
                <ul className="mt-4 space-y-2 text-sm text-slate-600">
                  <li className="flex gap-2">• Unbegrenzt Räume & Projekte</li>
                  <li className="flex gap-2">• Abweichungsbericht §6 HKVO</li>
                  <li className="flex gap-2">• Branding & API</li>
                </ul>
                <div className="mt-6"><a href="/dashboard"><button className="w-full h-11 px-4 rounded-2xl bg-heat-500 hover:bg-heat-600 text-white">Lizenz sichern</button></a></div>
              </div>
            </div>

            <div className="rounded-2xl border bg-white border-slate-200">
              <div className="p-5 border-b"><h3 className="font-semibold">Enterprise (B2B)</h3></div>
              <div className="p-5">
                <div className="text-4xl font-extrabold">Anfrage</div>
                <p className="mt-1 text-sm text-slate-500">Architekten, Bauunternehmen</p>
                <ul className="mt-4 space-y-2 text-sm text-slate-600">
                  <li className="flex gap-2">• DIN-Eingabemasken & Audits</li>
                  <li className="flex gap-2">• Mehrmandanten & SSO</li>
                  <li className="flex gap-2">• Priorisierter Support</li>
                </ul>
                <div className="mt-6"><a href="/analysis"><button className="w-full h-11 px-4 rounded-2xl border border-slate-300">Gespräch buchen</button></a></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="container-7xl py-16">
        <h2 className="text-3xl font-bold text-center">FAQ</h2>
        <div className="mt-8 grid md:grid-cols-2 gap-6 text-sm text-slate-700">
          <div className="rounded-2xl border bg-white">
            <div className="p-5 border-b font-semibold">Wie funktioniert der Abgleich mit Wetter-APIs?</div>
            <div className="p-5">Wir vergleichen lokale Messungen mit DWD/OpenWeather und speichern die Median-Differenz (T & hPa) zur Qualitätssicherung.</div>
          </div>
          <div className="rounded-2xl border bg-white">
            <div className="p-5 border-b font-semibold">Ist die private Nutzung wirklich kostenlos?</div>
            <div className="p-5">Ja. Gewerbliche Nutzung erfordert eine Lizenz. Die Lizenzprüfung ist technisch integriert.</div>
          </div>
          <div className="rounded-2xl border bg-white">
            <div className="p-5 border-b font-semibold">Kann ich PDF-Reports exportieren?</div>
            <div className="p-5">Ja, inkl. Abweichungsbericht mit §6 HKVO-Hinweis und optionalem Branding in Pro/Enterprise.</div>
          </div>
          <div className="rounded-2xl border bg-white">
            <div className="p-5 border-b font-semibold">Welche Sensoren werden unterstützt?</div>
            <div className="p-5">Start mit Demo/Simulator und BLE/WiFi; Bosch-Sensoren sind als bevorzugter Hersteller vorgesehen.</div>
          </div>
        </div>
      </section>
    </div>
  )
}
