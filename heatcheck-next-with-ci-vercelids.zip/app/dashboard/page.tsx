"use client";
import KPICard from "@/components/dashboard/KPICard";
import OptimizationTip from "@/components/dashboard/OptimizationTip";
import MiniChart from "@/components/dashboard/MiniChart";

export default function DashboardPage(){
  return (
    <div className="container-7xl py-10">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard label="Verbrauch heute" value="12.3 kWh" hint="Ø 10.8 kWh" />
        <KPICard label="Forecast" value="+4%" hint="vs. letzte Woche" />
        <KPICard label="Ø Raumtemp." value="20.8°C" hint="±0.6°C" />
        <KPICard label="Feuchte" value="47%" hint="Druck 1009 hPa" />
      </div>
      <div className="mt-8 rounded-2xl border bg-white p-6">
        <h2 className="font-semibold">Tagesverlauf</h2>
        <div className="mt-4"><MiniChart data={[0.1,0.2,0.3,0.25,0.4,0.35,0.5,0.45,0.6,0.55,0.7,0.65]} /></div>
      </div>
      <div className="mt-8 grid md:grid-cols-2 gap-6">
        <OptimizationTip title="Heizprofil optimieren">
          Senke die Nacht-Solltemperatur im Schlafzimmer um 0.5°C. Erwartete Einsparung 3–5% bei unverändertem Komfort.
        </OptimizationTip>
        <OptimizationTip title="Lüftungsfenster anpassen">
          Stoßlüften 2× täglich für 5 Minuten reduziert Feuchte-Spitzen, ohne Heizlast signifikant zu erhöhen.
        </OptimizationTip>
      </div>
    </div>
  )
}
