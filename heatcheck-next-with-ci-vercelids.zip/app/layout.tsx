import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "HeatCheck – Heizverbrauch transparent & smart",
  description: "Echtzeit-Heizbedarf auf Raumebene mit Wetterabgleich, PDF-Abweichungsbericht (§6 HKVO) und KI-Tipps.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body className="min-h-screen bg-gradient-to-b from-heat-50 to-white text-slate-800">
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
