import RoomCard from "@/components/room/RoomCard";

export default function RoomsPage(){
  const rooms = [
    { name: "Wohnzimmer", temp: 21.3, target: 20.5, deviation: 3 },
    { name: "Schlafzimmer", temp: 18.9, target: 19.5, deviation: -4 },
    { name: "Küche", temp: 20.1, target: 20.0, deviation: 1 },
    { name: "Bad", temp: 22.4, target: 22.0, deviation: 2 },
  ];
  return (
    <div className="container-7xl py-10">
      <h1 className="text-2xl font-bold">Räume</h1>
      <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {rooms.map((r) => <RoomCard key={r.name} {...r} />)}
      </div>
    </div>
  )
}
