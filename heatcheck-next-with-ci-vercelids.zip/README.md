# HeatCheck – Next.js App

Eine vorkonfigurierte Next.js (App Router) App mit TailwindCSS, minimalen UI-Komponenten, Seitenstruktur (Landing, Demo, Dashboard, Räume, Einstellungen, Analyse) und eingebundenen Assets (Logo, Hero-Hintergrund).

## Schnellstart
```bash
npm install
npm run dev
# öffne http://localhost:3000
```

## Struktur
- `app/` – Seiten (App Router)
- `components/` – UI & Feature-Komponenten
- `public/heatcheck-logo.png`, `public/hero-bg.jpg` – von dir bereitgestellte Assets
- Tailwind ist vorkonfiguriert (siehe `tailwind.config.ts` und `app/globals.css`).

## Hinweise
- Der Button **PDF Abweichungsbericht** nutzt den Browser-Druckdialog (`window.print()`).
- Für echte Sensoranbindung, Wetter-APIs (DWD/OpenWeather) und PDF-Erstellung kannst du später eigene Routen/Server-APIs ergänzen.

---

## Deployment

### Vercel (empfohlen)
1. Repo zu GitHub/GitLab/Bitbucket pushen.
2. In Vercel „New Project“ → Repo wählen.
3. Framework: **Next.js**, Build: `npm run build` (automatisch gesetzt).
4. Environment-Variablen aus `.env.example` übernehmen.
5. Deploy.

> Optional: `vercel.json` liegt bei und nutzt `@vercel/next` Build.

### Docker
```bash
# Build
docker build -t heatcheck .
# Run
docker run -p 3000:3000 --env-file .env heatcheck
```

### Docker Compose
```bash
docker compose up --build
```
