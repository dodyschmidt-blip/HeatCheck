import { Card, CardContent } from "@/components/ui/Card";

export default function KPICard({ label, value, hint }: { label: string; value: string; hint?: string; }){
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-sm text-slate-500">{label}</div>
        <div className="mt-1 text-2xl font-semibold">{value}</div>
        {hint ? <div className="mt-1 text-slate-500">{hint}</div> : null}
      </CardContent>
    </Card>
  )
}
