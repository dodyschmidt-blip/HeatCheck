import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";

export default function OptimizationTip({ title, children }: { title: string; children: React.ReactNode }){
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-slate-700">{children}</CardContent>
    </Card>
  )
}
