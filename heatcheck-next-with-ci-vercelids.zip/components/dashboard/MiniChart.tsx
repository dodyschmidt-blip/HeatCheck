"use client";
import { useEffect, useRef } from "react";

// Minimal tiny chart using canvas for demo purposes
export default function MiniChart({ data }: { data: number[] }){
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if(!canvas) return;
    const ctx = canvas.getContext("2d");
    if(!ctx) return;
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0,0,w,h);
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#FF6F14";
    ctx.beginPath();
    data.forEach((v,i) => {
      const x = (i/(data.length-1))*w;
      const y = h - (v * h);
      if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    });
    ctx.stroke();
  }, [data]);
  return <canvas ref={ref} width={300} height={80} className="w-full h-20" />;
}
