import { Card, CardContent } from "@/components/ui/Card";

export default function RoomCard({ name, temp, target, deviation }: { name: string; temp: number; target: number; deviation: number; }){
  const devColor = deviation >= 0 ? "text-emerald-600" : "text-rose-600";
  const devStr = `${deviation >=0 ? "+" : ""}${deviation}%`;
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-sm text-slate-500">{name}</div>
        <div className="mt-1 text-2xl font-semibold">{temp.toFixed(1)}°C</div>
        <div className="mt-1 text-slate-500">Soll: {target.toFixed(1)}°C • Abweichung: <span className={devColor}>{devStr}</span></div>
      </CardContent>
    </Card>
  )
}
