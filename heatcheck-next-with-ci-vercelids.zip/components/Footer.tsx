export default function Footer(){
  return (
    <footer className="border-t bg-white mt-16">
      <div className="container-7xl py-10">
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-heat-500 to-heat-300 shadow-md" />
            <span className="font-bold">HeatCheck</span>
          </div>
          <div className="text-sm text-slate-600 flex gap-6">
            <a href="#">Impressum</a>
            <a href="#">Datenschutz</a>
            <a href="#">Kontakt</a>
          </div>
        </div>
        <p className="mt-6 text-xs text-slate-500">© {new Date().getFullYear()} HeatCheck. Alle Rechte vorbehalten.</p>
      </div>
    </footer>
  )
}
