"use client";
import Image from "next/image";
import Link from "next/link";
import Button from "@/components/ui/Button";

export default function Navbar(){
  return (
    <nav className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-heat-100">
      <div className="container-7xl h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Image src="/heatcheck-logo.png" width={32} height={32} alt="HeatCheck Logo" className="rounded-lg" />
          <span className="font-bold text-xl tracking-tight">HeatCheck</span>
          <span className="ml-2 text-xs px-2 py-0.5 rounded-full bg-heat-100 text-heat-800 border border-heat-200">Preview</span>
        </Link>
        <div className="hidden md:flex items-center gap-6 text-sm">
          <Link href="/#features" className="hover:text-slate-900">Funktionen</Link>
          <Link href="/demo" className="hover:text-slate-900">Demo</Link>
          <Link href="/dashboard" className="hover:text-slate-900">Dashboard</Link>
          <Link href="/#pricing" className="hover:text-slate-900">Preise</Link>
          <Link href="/#faq" className="hover:text-slate-900">FAQ</Link>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="ghost" className="hidden sm:inline-flex">Login</Button>
          <Button>Jetzt starten</Button>
        </div>
      </div>
    </nav>
  )
}
