import * as React from "react";
import { cn } from "@/components/ui/cn";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
}

export default function Button({ className, variant="default", size="md", ...props }: ButtonProps){
  const base = "inline-flex items-center justify-center rounded-2xl font-medium transition focus:outline-none focus:ring-2 focus:ring-heat-300";
  const variants = {
    default: "bg-heat-500 text-white hover:bg-heat-600",
    outline: "border border-heat-300 text-heat-800 hover:bg-heat-50",
    ghost: "text-slate-700 hover:bg-slate-100"
  };
  const sizes = {
    sm: "h-9 px-3 text-sm",
    md: "h-11 px-4",
    lg: "h-12 px-5 text-lg"
  };
  return <button className={cn(base, variants[variant], sizes[size], className)} {...props} />;
}
